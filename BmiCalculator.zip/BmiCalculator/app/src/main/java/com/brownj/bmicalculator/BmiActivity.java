package com.brownj.bmicalculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import static android.widget.Toast.*;

public class BmiActivity extends AppCompatActivity {

    TextView mWeightUnit;
    TextView mHeightUnit;
    private EditText mWeight;
    private EditText mHeight;
    String unit;
    Button calcButton;
    RadioGroup units;
    RadioButton metric;
    RadioButton english;
    String temp1;
    String temp2;

    CalcBMI mBmi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        calcButton = findViewById(R.id.calc_button);
        units = findViewById(R.id.unit_selection);
        metric = findViewById(R.id.metric_units);
        mWeightUnit.setText(R.string.metric_weight);
        mHeightUnit.setText(R.string.metric_height);

        Log.i("Units",String.valueOf(units.getCheckedRadioButtonId()));
//        if(units.getCheckedRadioButtonId() == metric.getId()){
//            mWeightUnit.setText(R.string.metric_weight);
//            mHeightUnit.setText(R.string.metric_height);
//            unit = "metric";

//        }
        mWeight = findViewById(R.id.weight);
        mHeight = findViewById(R.id.height);

        calcButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                temp1 = mWeight.getText().toString();
                temp2 = mHeight.getText().toString();

                mBmi = new CalcBMI(temp1, temp2);
                mBmi.calcReturnBmi();
                String result = mBmi.getScalePosition();

                Toast.makeText(BmiActivity.this, result, Toast.LENGTH_SHORT).show();

            }
        });

    }



}


