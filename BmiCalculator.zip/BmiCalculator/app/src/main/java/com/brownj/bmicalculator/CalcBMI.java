package com.brownj.bmicalculator;

public class CalcBMI {

    private double weight;
    private double height;
    private double myBMI;
    private String scalePosition;

    Double[] bmiScale = {18.5, 24.9, 29.9};
    String[] bmiMeaning = {"Thin", "Healthy", "Over Weight", "Obese"};

    public CalcBMI(String weight, String height){

        this.weight = Double.parseDouble(weight);
        this.height = Double.parseDouble(height);

    }

    public String getWeight(){
        String temp;
        temp = String.valueOf(weight);

        return temp;
    }

    public String getHeight(){
        String temp;
        temp = String.valueOf(height);

        return temp;
    }

    private String convertBMI(){
        String temp;

        temp = String.valueOf(myBMI);

        return temp;
    }

    public String getScalePosition(){
        return scalePosition;
    }

    private void calculateBmi(){
        myBMI = 703 * (weight/(height * height));
    }

    private void compareBmiResult(){
        //takes bmi, compares chart
        if(myBMI <= bmiScale[0]){
            scalePosition = bmiMeaning[0];
        }
        else if(myBMI > bmiScale[0] && myBMI <= bmiScale[1]){
            scalePosition = bmiMeaning[1];
        }
        else if(myBMI > bmiScale[1] && myBMI <= bmiScale[2]){
            scalePosition = bmiMeaning[2];
        }
        else{
            scalePosition = bmiMeaning[3];
        }

    }

    public void calcReturnBmi(){
        //runs bmi calculation, compare function, returns results
        calculateBmi();
        compareBmiResult();

    }

}
